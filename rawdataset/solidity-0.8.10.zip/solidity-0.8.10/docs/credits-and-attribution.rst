.. This page is meant to be linked to from the footer.

:orphan:

#######################
Credits and Attribution
#######################

Website icons
=============

.. |icon-share-solid| image:: _static/img/solid-share-arrow.svg
.. _share icon: https://fontawesome.com/v5.15/icons/share?style=solid
.. _Font Awesome Free License: https://fontawesome.com/license/free

+-------------------------+-----------------------------------------------------------------------+
| Icon                    | Attribution                                                           |
+=========================+=======================================================================+
| |icon-share-solid|      | - Source: `share icon`_ from Font Awesome 5.15.0.                     |
|                         | - License: `Font Awesome Free License`_ (CC BY 4.0).                  |
+-------------------------+-----------------------------------------------------------------------+

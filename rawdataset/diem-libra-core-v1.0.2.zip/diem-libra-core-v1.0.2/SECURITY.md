# Security Policies and Procedures

Please see Libra's
[security policies](https://developers.libra.org/docs/policies/security) and
procedures for reporting vulnerabilities.

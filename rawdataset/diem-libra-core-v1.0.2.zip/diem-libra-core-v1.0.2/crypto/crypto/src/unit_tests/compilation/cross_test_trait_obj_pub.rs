// Copyright (c) The Libra Core Contributors
// SPDX-License-Identifier: Apache-2.0

use libra_crypto::traits::*;

fn main() {
    let mut l: Vec<Box<dyn PublicKey>> = vec![];
}

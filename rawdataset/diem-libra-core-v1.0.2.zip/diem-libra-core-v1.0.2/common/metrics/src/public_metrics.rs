// Copyright (c) The Libra Core Contributors
// SPDX-License-Identifier: Apache-2.0

// A list of metrics which will be made public to all the partners
pub const PUBLIC_METRICS: &[&str] = &["libra_network_peers", "revision"];

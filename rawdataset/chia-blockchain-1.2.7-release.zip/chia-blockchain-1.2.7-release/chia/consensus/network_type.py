from enum import IntEnum


class NetworkType(IntEnum):
    MAINNET = 0
    TESTNET = 1

# Installation

Install instructions have been moved to the [INSTALL](https://github.com/Chia-Network/chia-blockchain/wiki/INSTALL) section of the repository [Wiki](https://github.com/Chia-Network/chia-blockchain/wiki).

After installing, follow the remaining instructions in the
[Quick Start Guide](https://github.com/Chia-Network/chia-blockchain/wiki/Quick-Start-Guide)
to run the software.
